// Name: John Reed
// Class: Systems Programming Section: 01
// Assignment: Lab 1 - Simple 'C' Programs & The Preprocessor - Program I

#include <stdio.h>

int main(void) {
    printf("John Reed\n");
    printf("\"'Portability is for people who cannot write new programs' "
           "-me, right now (with tounge in cheek)\"\n");
    printf("    -Linus Torvalds\n");
}
